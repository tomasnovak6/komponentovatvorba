﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            int cislo = 5;
            int cislo2 = cislo + 10;
            System.Console.WriteLine(cislo);
            System.Console.WriteLine(cislo2);
            System.Console.ReadKey();
        }
    }
}
